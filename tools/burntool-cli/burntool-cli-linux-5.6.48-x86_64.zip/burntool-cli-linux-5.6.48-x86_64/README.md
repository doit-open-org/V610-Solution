# burntool-cli Linux 使用说明

`burntool-cli` 由四博智联基于芯片厂商官方烧录工具精简适配，适用于 Hi3516CV610 和 SD3403V100 NAND 烧写。

## 文件

- `burntool-cli`
- `99-burntool-cli.rules`
- `README.md`

## 配置 USB 权限

首次使用 USB 烧写时执行：

`sudo install -m 0644 99-burntool-cli.rules /etc/udev/rules.d/99-burntool-cli.rules`

`sudo udevadm control --reload-rules`

`sudo udevadm trigger`

然后重新插拔板卡。若系统存在 `plugdev` 组，当前用户应属于该组。

## 使用

USB 烧写：

`./burntool-cli -u -x /path/to/nand_burn_table.xml`

串口烧写：

`./burntool-cli -s /dev/ttyUSB0 -x /path/to/nand_burn_table.xml`

## 进入烧写模式

运行命令并看到提示后：

- 串口：工具会先拉一下 RTS 自动复位；RTS 未接复位电路的板子，看到提示后重新上电或按下 RST 键。
- USB：按住 UPDATE，再重新上电或按下 RST 键；看到 `Boot 已运行` 后再松开 UPDATE。

建议先加 `--boot-only` 只验证 BootROM 下载（不擦写 NAND），成功后再完整烧写。

## 参数

- `-u`：使用 USB BootROM 模式。
- `-s DEVICE`：使用串口模式，例如 `-s /dev/ttyUSB0`。
- `-x FILE`：指定分区 XML 文件，必须设置。
- `-n CHIP`：指定芯片，支持 `Hi3516CV610`、`SD3403V100`；默认 `Hi3516CV610`。
- `-b BAUD`：指定串口波特率，默认 `115200`。
- `--part NAME,...`：仅烧写指定分区，例如 `--part boot,env`；默认烧写 XML 中 `Sel="1"` 的分区。
- `--usb-vid ID`：覆盖 USB VID，例如 `--usb-vid 0x3361`。
- `--usb-pid ID`：覆盖 USB PID，例如 `--usb-pid 0xd001`。
- `--version`：显示版本。

执行烧写前，请确认芯片型号、分区 XML 和镜像文件正确。